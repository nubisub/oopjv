public class Main {
    public static void main(String[] args) {
        Person satu = new Person("Paul Allen", "homeless");
        System.out.println(satu);

        Student dua = new Student("Kelly", "Kolkata", "Electrical Engineering", 2012, 666);
        System.out.println(dua);

        Staff tiga = new Staff("Linus", "West Virginia", "SD Percobaan", 669);
        System.out.println(tiga);

    }
}
