import java.util.Date;

public class Main {
    public static void main(String[] args) {
        Visit x = new Visit("Paul Allen", new Date());
        System.out.println(x.customer.toString());
        System.out.println("Date = " + x.getDate());

        x.setServiceExpense(100);
        x.setProductExpense(100);

        x.customer.setMember(true);
        x.customer.setMemberType("premium");
        System.out.println(x);
    }
}
