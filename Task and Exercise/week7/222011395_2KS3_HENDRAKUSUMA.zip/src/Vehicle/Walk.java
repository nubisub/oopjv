package Vehicle;

public class Walk implements Vehicle {
    public String bestRoute() {
        // Pake Dijkstra
       return("Bole pake jalan paling sempit (setapak), nggak peduli traffick jam");
    }
}
