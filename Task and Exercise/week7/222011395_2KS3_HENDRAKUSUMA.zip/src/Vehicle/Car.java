package Vehicle;


public class Car implements Vehicle {
        // public boolean avoidTrafficJam;
        // public boolean avoidTolls;
        // public boolean avoidHighways;
        public String bestRoute() {
        // Pake Dijkstra

        // avoidHighways = false;
        // avoidTolls = false;
        // avoidTrafficJam = true;
        
        return("Avoid Traffic Jam, Tolls available, Highways available");

    }
}
