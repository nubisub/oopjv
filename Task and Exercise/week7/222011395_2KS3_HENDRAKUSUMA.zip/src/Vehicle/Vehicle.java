package Vehicle;

public interface Vehicle {
    // best route
    public String bestRoute();
}
