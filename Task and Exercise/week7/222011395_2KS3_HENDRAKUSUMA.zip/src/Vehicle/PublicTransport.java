package Vehicle;

public class PublicTransport implements Vehicle {
    public String bestRoute() {
        // Pake Dijkstra
        return("Cari info pakai API transjogja/ transportasi umum (Jam Operasional (kedatangan), Tarif, halte)");
    }
}
