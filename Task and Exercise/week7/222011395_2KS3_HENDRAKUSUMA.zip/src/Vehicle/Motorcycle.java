package Vehicle;

public class Motorcycle implements Vehicle {
    public String bestRoute() {
        // Pake Dijkstra
        return("Avoid tolls, Avoid highways, Avoid traffic jams, jalan tikus available");
    }
}
