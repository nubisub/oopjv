package Singleton;

public interface Notifier {
    public void sendNotification(String notification);
}
