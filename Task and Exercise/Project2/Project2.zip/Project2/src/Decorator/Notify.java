package Decorator;

public interface Notify {
    public void notify(String notification);
}
