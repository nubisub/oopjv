package Decorator;

public interface Notifier {
    public void sendNotification(String notification);
}
