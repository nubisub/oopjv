package Decorator;

public class Basic implements Notifier {
    @Override
    public void sendNotification(String notification) {
        // System.out.println("Via Basic : " + notification);
    }
}
