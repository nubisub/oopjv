public class Administrative extends Employee{
    public Administrative(int ssNo, String name, String email) {
        super(ssNo, name, email);
    }
}
