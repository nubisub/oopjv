import java.util.List;
public class Faculty {
    public String name;
    private List<Institute> daftarinstitute;
    public Faculty(String name, List<Institute> daftarinstitute) {
        this.name = name;
        this.daftarinstitute = daftarinstitute;
    }
    public List<Institute> getDaftarinstitute() {
        return daftarinstitute;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
}
