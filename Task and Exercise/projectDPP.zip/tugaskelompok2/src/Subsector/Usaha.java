package Subsector;

public interface Usaha {
    public String getSubsector();
    public boolean isUsaha();
    public void setUsaha(boolean usaha);
}
