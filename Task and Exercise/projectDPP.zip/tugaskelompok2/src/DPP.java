

public class DPP {

    public DPP(boolean b, String status) {
    }

}
