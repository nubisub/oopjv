package Validate;

public abstract class Validate {
    public abstract boolean isValid(String kode);
}
