package KIP;
// interface kode untuk semua kode yang diinput
public interface Kode {
    public void setKode(String kode);
    public String getKode();
    public String getNama();
}
